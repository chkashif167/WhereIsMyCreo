<?php
/**
 * Created by PhpStorm.
 * User: dhiraj.gangoosirdar
 * Date: 3/18/2015
 * Time: 9:30 AM
 */

namespace com\checkout\ApiServices\Tokens\RequestModels;


class PaymentTokenCreate extends \com\checkout\ApiServices\Charges\RequestModels\BaseCharge
{

}